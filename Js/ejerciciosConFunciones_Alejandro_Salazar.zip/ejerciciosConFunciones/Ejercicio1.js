//Ejercicio 1

//1.- Declara una función llamada saludo() que muestre una alerta de Bienvenida al visitante al invocarla por la consola.
function saludo() {
    alert('Bienvenido visitante')
}

saludo()