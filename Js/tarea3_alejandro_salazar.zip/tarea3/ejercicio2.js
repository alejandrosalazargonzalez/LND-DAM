/**
 * @ @author: alejandrosalazargonzalez
 * @ @version: 1.0.0
 */



// Ejercicio 2

//   1.- Pedirle al usuario que introduzca un número
let numero = Number(prompt('Ingresa un numero'))

//   2.- Comparar si es par o no, a través de un if/else. Si es par que muestre una alerta indicando
//       que el número es par, o en caso contrario, que muestre una alerta de que es impar.
if (numero%2 === 0) {
    alert('es un nùmero par')
} else {
    alert('es un nùmero impar')    
}

