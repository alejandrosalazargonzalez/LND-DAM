//Ejercicio 2
// 1.- Utiliza la  consola para escribir una expresión que compare dos strings y produzca un valor true
let palabra1 = "hola"
let palabra2 = "adios"
console.log(palabra1 === "hola")
// 2.- Escribe una expresión comparando dos strings que de devuelva false
console.log(palabra1 === palabra2)
// 3.- Escribe una expresión que involucre un string y un número, y devuelva False
let numero = 1
let numeroPalabra = "1"
console.log(numero===numeroPalabra)
// 4.- Escribe una expresión que involucre un string y un número y devuelva true
console.log(numero==numeroPalabra)
