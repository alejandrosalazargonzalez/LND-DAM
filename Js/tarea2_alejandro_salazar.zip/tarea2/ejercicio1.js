
//Ejercicio 1
//  1.- ¿Qué devuelve cada expresión?
//  Expr. 1:
    let x =30
    let y ="a"
    y=== "b" ||  x>=30
    //devuelve true por el x>=30
//  Expr. 2
    x=15
    y=2
    ! (x=="15" || x===y ) && !(y!==2 && x<=y)
    //devuelve true porque se esta negando el resultado


