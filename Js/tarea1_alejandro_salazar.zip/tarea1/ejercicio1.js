//Ejercicio1:

//1.- Declara una variable llamada nombre en tu consola y asígnale tu nombre
let nombre = "Alejandro"
//2.- Declara una variable llamada apellido y asígnale como valor tu apellido
let apellido = "Salazar"
//3.- Muestra por consola las variables nombre y apellido
console.log(`Mi nombre es ${nombre} y mi apellido es ${apellido}`)