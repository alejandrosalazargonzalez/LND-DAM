//Ejercicio 3

//1.- Crea tres variables, numero1, numero2 y resultado
let numero1
let numero2
let resultado

//2.- Pídele al usuario que ingrese los valores de las variables numero1 y numero2, mediante un prompt()
numero1 = Number(prompt('Ingrese un valor'))
numero2 = Number(prompt('Ingrese otro valor'))
//3.- Asigna a la variable resultado el valor de la suma de numero1 y numero2
resultado = numero1 +numero2

//4.- Muestra un alerta con el mensaje "El resultado es: (resultado)"
alert('El resultado es: ' + resultado)
