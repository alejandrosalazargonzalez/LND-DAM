// Ejercicio 5

//   1.- Declara una variable que se llame texto, y asígnale el método prompt() para que le puedas solicitar al usuario que ingrese un texto
let texto = prompt('ingresa un texto')
//   2.- Calcula su largo, y muestra un alert() que diga "El largo del texto es: XX"
alert('El largo del texto es:' + texto.length)