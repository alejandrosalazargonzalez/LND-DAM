
//ejercicio 4

//   1.- Crea dos variables, numero y numeroTriple
let numero
let numeroTriple

//   2.- Pídele al usuario que ingrese el valor del número a calcular mediante un prompt()
numero = Number(prompt('ingresa un valor'))
//   3.- Asigna a la variable numeroTriple el valor de la multiplicación por 3 del número ingresado
numeroTriple = numero * 3
//   4.- Muestra el resultado por consola con el mensaje "el tríple de este número es: (xx)"
console.log('el triple numero de '+ numero + ' es ' + numeroTriple)
